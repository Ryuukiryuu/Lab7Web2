const { createApp, reactive }                = Vue;
const { createRouter, createWebHashHistory } = VueRouter;

const apiUrl = 'http://localhost/lab11_ci/ci4/public';

// Global reactive store — diakses oleh semua komponen
const store = reactive({
    isLoggedIn: localStorage.getItem('isLoggedIn') === 'true'
});
window.appStore = store;

// ============================================================
// AXIOS INTERCEPTORS — Praktikum 14
// ============================================================
axios.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('userToken');
        if (token) {
            config.headers['Authorization'] = 'Bearer ' + token;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

axios.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response && error.response.status === 401) {
            alert('Sesi Anda telah berakhir. Silakan login kembali.');
            localStorage.clear();
            store.isLoggedIn = false;
            window.location.href = '#/login';
        }
        return Promise.reject(error);
    }
);

// ============================================================
// ROUTES — Praktikum 12 & 13
// ============================================================
const routes = [
    { path: '/',        component: Home  },
    { path: '/login',   component: Login },
    { path: '/about',   component: About,   meta: { requiresAuth: true } },
    { path: '/artikel', component: Artikel, meta: { requiresAuth: true } },
];

const router = createRouter({
    history: createWebHashHistory(),
    routes,
});

// ============================================================
// NAVIGATION GUARDS — Praktikum 13
// ============================================================
router.beforeEach((to, from, next) => {
    const isAuthenticated = localStorage.getItem('isLoggedIn') === 'true';
    if (to.matched.some(record => record.meta.requiresAuth) && !isAuthenticated) {
        alert('Akses Ditolak! Anda harus login terlebih dahulu.');
        next('/login');
    } else {
        next();
    }
});

// ============================================================
// ROOT INSTANCE
// ============================================================
const app = createApp({
    data() {
        return { store };
    },
    methods: {
        logout() {
            if (confirm('Apakah Anda yakin ingin keluar aplikasi?')) {
                localStorage.clear();
                store.isLoggedIn = false;
                this.$router.push('/');
            }
        },
    },
});

app.use(router);
app.mount('#app');