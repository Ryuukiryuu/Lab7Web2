const About = {
    template: `
        <div class="about-container">
            <h2>Profil Mahasiswa</h2>
            <div class="profile-card">
                <div class="profile-avatar">WA</div>
                <table class="profile-table">
                    <tr><th>Nama</th><td>Wahyu Andika</td></tr>
                    <tr><th>NIM</th><td>312410182</td></tr>
                    <tr><th>Kelas</th><td>I241B</td></tr>
                    <tr><th>Mata Kuliah</th><td>Pemrograman Web 2</td></tr>
                    <tr><th>Universitas</th><td>Universitas Pelita Bangsa</td></tr>
                </table>
            </div>
        </div>
    `
};