const Login = {
    template: `
        <div class="login-container">
            <div class="login-box">
                <h2>Form Login Admin</h2>
                <form @submit.prevent="handleLogin">
                    <div class="form-group">
                        <label>Username / Email</label>
                        <input type="text" v-model="username"
                            placeholder="Masukkan username" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" v-model="password"
                            placeholder="Masukkan password" required>
                    </div>
                    <button type="submit" class="btn-login" :disabled="loading">
                        {{ loading ? 'Memproses...' : 'Masuk Aplikasi' }}
                    </button>
                </form>
                <p v-if="errorMessage" class="error-msg">{{ errorMessage }}</p>
            </div>
        </div>
    `,
    data() {
        return {
            username:     '',
            password:     '',
            errorMessage: '',
            loading:      false,
        };
    },
    methods: {
        handleLogin() {
            this.loading      = true;
            this.errorMessage = '';

            axios.post(apiUrl + '/api/login', {
                username: this.username,
                password: this.password,
            })
            .then(response => {
                if (response.data.status === 200) {
                    localStorage.setItem('isLoggedIn', 'true');
                    localStorage.setItem('userToken', response.data.data.token);

                    // Update global store langsung — tidak perlu reload
                    window.appStore.isLoggedIn = true;

                    this.$router.push('/artikel');
                }
            })
            .catch(error => {
                if (error.response && error.response.data.messages) {
                    this.errorMessage = error.response.data.messages;
                } else {
                    this.errorMessage = 'Terjadi kesalahan jaringan atau server.';
                }
            })
            .finally(() => {
                this.loading = false;
            });
        },
    },
};